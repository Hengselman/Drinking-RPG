// Script om admin account aan te maken
// Run dit lokaal na het configureren van Firebase

import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, doc, setDoc } from 'firebase/firestore';

// Vul hier je Firebase config in
const firebaseConfig = {
  // YOUR CONFIG HERE
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

async function createAdminAccount() {
  const adminEmail = 'admin@drinkrpg.nl';
  const adminPassword = 'admin123'; // VERANDER DIT!
  
  try {
    // Maak admin account
    const userCredential = await createUserWithEmailAndPassword(auth, adminEmail, adminPassword);
    
    // Maak admin profiel in Firestore
    await setDoc(doc(db, 'users', userCredential.user.uid), {
      email: adminEmail,
      createdAt: new Date().toISOString(),
      isAdmin: true,
      characters: []
    });
    
    console.log('Admin account aangemaakt!');
    console.log('Email:', adminEmail);
    console.log('Wachtwoord:', adminPassword);
    console.log('BELANGRIJK: Verander het wachtwoord na eerste login!');
    
  } catch (error) {
    console.error('Fout bij aanmaken admin account:', error);
  }
}

// Uncomment om te runnen
// createAdminAccount();