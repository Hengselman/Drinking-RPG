import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { doc, updateDoc, getDoc } from 'firebase/firestore';
import { motion } from 'framer-motion';
import { ArrowLeft, Check } from 'lucide-react';
import toast from 'react-hot-toast';
import { CHARACTER_CLASSES, HATS } from '../data/gameData';

export default function CreateCharacter() {
  const [name, setName] = useState('');
  const [selectedClass, setSelectedClass] = useState(null);
  const [selectedHat, setSelectedHat] = useState('viking');
  const [loading, setLoading] = useState(false);
  const { slotIndex } = useParams();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  async function handleCreate() {
    if (!name || !selectedClass) {
      toast.error('Vul een naam in en kies een class!');
      return;
    }

    try {
      setLoading(true);
      
      // Haal huidige karakters op
      const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
      const userData = userDoc.data();
      const characters = userData.characters || Array(5).fill(null);
      
      // Maak nieuw karakter
      const newCharacter = {
        name,
        class: CHARACTER_CLASSES[selectedClass],
        hat: HATS[selectedHat.toUpperCase()],
        xp: 0,
        currency: 100, // Start geld
        inventory: [],
        createdAt: new Date().toISOString()
      };
      
      // Update karakter in de juiste slot
      characters[parseInt(slotIndex)] = newCharacter;
      
      // Sla op in database
      await updateDoc(doc(db, 'users', currentUser.uid), {
        characters,
        selectedCharacter: parseInt(slotIndex)
      });
      
      toast.success('Karakter aangemaakt!');
      navigate(`/game/${slotIndex}`);
    } catch (error) {
      toast.error('Fout bij aanmaken karakter');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-900 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={() => navigate('/characters')}
            className="pixel-button bg-gray-600 mr-4"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h1 className="font-pixel text-3xl text-yellow-400">
            NIEUW KARAKTER - SLOT {parseInt(slotIndex) + 1}
          </h1>
        </div>

        {/* Naam Input */}
        <div className="pixel-card mb-6">
          <h2 className="font-pixel text-xl text-yellow-400 mb-4">Naam</h2>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={12}
            placeholder="Voer naam in..."
            className="w-full px-4 py-3 bg-slate-700 border-2 border-slate-600 text-white font-pixel text-sm"
          />
        </div>

        {/* Class Selectie */}
        <div className="pixel-card mb-6">
          <h2 className="font-pixel text-xl text-yellow-400 mb-4">Kies Class</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(CHARACTER_CLASSES).map(([key, classData]) => (
              <motion.button
                key={key}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedClass(key)}
                className={`p-4 pixel-card ${
                  selectedClass === key ? 'border-yellow-400' : ''
                } ${classData.color}`}
              >
                <h3 className="font-pixel text-sm mb-2">{classData.name}</h3>
                <p className="font-pixel text-xs mb-2">{classData.description}</p>
                <div className="font-pixel text-xs text-left">
                  <p>STA: {classData.baseStats.stamina}</p>
                  <p>STR: {classData.baseStats.strength}</p>
                  <p>SPD: {classData.baseStats.speed}</p>
                </div>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Hoedje Selectie */}
        <div className="pixel-card mb-6">
          <h2 className="font-pixel text-xl text-yellow-400 mb-4">Kies Hoedje</h2>
          <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
            {Object.entries(HATS).map(([key, hat]) => (
              <motion.button
                key={key}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setSelectedHat(key.toLowerCase())}
                className={`p-4 pixel-card ${
                  selectedHat === key.toLowerCase() ? 'border-yellow-400' : ''
                }`}
              >
                <div className="text-4xl mb-2">{hat.sprite}</div>
                <p className="font-pixel text-xs">{hat.name}</p>
                {hat.price > 0 && (
                  <p className="font-pixel text-xs text-gray-400">
                    {hat.price} coins
                  </p>
                )}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Create Button */}
        <button
          onClick={handleCreate}
          disabled={loading || !name || !selectedClass}
          className="w-full pixel-button bg-green-600 text-lg flex items-center justify-center gap-2"
        >
          <Check className="w-5 h-5" />
          {loading ? 'Aanmaken...' : 'Karakter Aanmaken'}
        </button>
      </div>
    </div>
  );
}