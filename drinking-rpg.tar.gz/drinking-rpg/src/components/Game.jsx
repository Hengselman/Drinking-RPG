import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { motion } from 'framer-motion';
import { ArrowLeft, ShoppingBag, Trophy, Coins } from 'lucide-react';
import toast from 'react-hot-toast';
import { calculateLevel, getXpForNextLevel, SHOP_ITEMS, HATS, DRINKING_GAMES } from '../data/gameData';

export default function Game() {
  const [character, setCharacter] = useState(null);
  const [loading, setLoading] = useState(true);
  const [shopOpen, setShopOpen] = useState(false);
  const { slotIndex } = useParams();
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    loadCharacter();
  }, [slotIndex, currentUser]);

  async function loadCharacter() {
    try {
      const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
      if (userDoc.exists()) {
        const userData = userDoc.data();
        const char = userData.characters[parseInt(slotIndex)];
        if (char) {
          setCharacter(char);
        } else {
          navigate('/characters');
        }
      }
    } catch (error) {
      toast.error('Fout bij laden karakter');
    } finally {
      setLoading(false);
    }
  }

  async function buyItem(item) {
    if (character.currency < item.price) {
      toast.error('Niet genoeg munten!');
      return;
    }

    try {
      const updatedCharacter = {
        ...character,
        currency: character.currency - item.price,
        inventory: [...(character.inventory || []), item]
      };

      // Update in database
      const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
      const userData = userDoc.data();
      const characters = [...userData.characters];
      characters[parseInt(slotIndex)] = updatedCharacter;

      await updateDoc(doc(db, 'users', currentUser.uid), { characters });
      
      setCharacter(updatedCharacter);
      toast.success(`${item.name} gekocht!`);
    } catch (error) {
      toast.error('Fout bij kopen item');
    }
  }

  async function buyHat(hat) {
    if (character.currency < hat.price) {
      toast.error('Niet genoeg munten!');
      return;
    }

    try {
      const updatedCharacter = {
        ...character,
        currency: character.currency - hat.price,
        hat: hat
      };

      // Update in database
      const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
      const userData = userDoc.data();
      const characters = [...userData.characters];
      characters[parseInt(slotIndex)] = updatedCharacter;

      await updateDoc(doc(db, 'users', currentUser.uid), { characters });
      
      setCharacter(updatedCharacter);
      toast.success(`${hat.name} gekocht!`);
    } catch (error) {
      toast.error('Fout bij kopen hoedje');
    }
  }

  if (loading || !character) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <p className="font-pixel text-white animate-pulse">Laden...</p>
      </div>
    );
  }

  const level = calculateLevel(character.xp);
  const xpForNext = getXpForNextLevel(character.xp);

  return (
    <div className="min-h-screen bg-slate-900 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={() => navigate('/characters')}
            className="pixel-button bg-gray-600"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h1 className="font-pixel text-3xl text-yellow-400">
            {character.name}
          </h1>
          <button
            onClick={() => setShopOpen(!shopOpen)}
            className="pixel-button bg-green-600 flex items-center gap-2"
          >
            <ShoppingBag className="w-4 h-4" />
            Shop
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Character Display */}
          <div className="pixel-card">
            <h2 className="font-pixel text-xl text-yellow-400 mb-4">Karakter</h2>
            <div className="text-center mb-4">
              <div className="text-8xl mb-4">{character.hat?.sprite || '🎩'}</div>
              <div className={`inline-block px-3 py-1 ${character.class.color} pixel-borders`}>
                <p className="font-pixel text-sm">{character.class.name}</p>
              </div>
            </div>
            
            {/* Stats */}
            <div className="space-y-2">
              <div className="flex justify-between font-pixel text-sm">
                <span>Level:</span>
                <span className="text-yellow-400">{level}</span>
              </div>
              <div className="flex justify-between font-pixel text-sm">
                <span>XP:</span>
                <span className="text-green-400">{character.xp} / {character.xp + xpForNext}</span>
              </div>
              <div className="w-full bg-gray-700 h-4 pixel-borders">
                <div 
                  className="bg-green-400 h-full transition-all duration-500"
                  style={{ width: `${(character.xp % 100)}%` }}
                />
              </div>
              <div className="flex justify-between font-pixel text-sm mt-4">
                <span>Munten:</span>
                <span className="text-yellow-400 flex items-center gap-1">
                  <Coins className="w-4 h-4" />
                  {character.currency}
                </span>
              </div>
            </div>
          </div>

          {/* Drinking Games */}
          <div className="pixel-card">
            <h2 className="font-pixel text-xl text-yellow-400 mb-4">Drankspellen</h2>
            <p className="font-pixel text-xs text-gray-400 mb-4">
              Win spellen om XP te verdienen!
            </p>
            <div className="space-y-3">
              {DRINKING_GAMES.map(game => (
                <div key={game.id} className="p-3 bg-slate-700 pixel-borders">
                  <h3 className="font-pixel text-sm text-yellow-400">{game.name}</h3>
                  <p className="font-pixel text-xs text-gray-400">{game.description}</p>
                  <p className="font-pixel text-xs text-green-400 mt-1">
                    +{game.xpReward} XP
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Inventory */}
          <div className="pixel-card">
            <h2 className="font-pixel text-xl text-yellow-400 mb-4">Inventory</h2>
            {character.inventory?.length > 0 ? (
              <div className="space-y-2">
                {character.inventory.map((item, index) => (
                  <div key={index} className="p-2 bg-slate-700 pixel-borders">
                    <p className="font-pixel text-sm">{item.name}</p>
                    <p className="font-pixel text-xs text-gray-400">{item.description}</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="font-pixel text-xs text-gray-500">Nog geen items...</p>
            )}
          </div>
        </div>

        {/* Shop Modal */}
        {shopOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50"
            onClick={() => setShopOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="pixel-card max-w-4xl w-full max-h-[80vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <h2 className="font-pixel text-2xl text-yellow-400 mb-6">SHOP</h2>
              
              {/* Hoedjes */}
              <div className="mb-8">
                <h3 className="font-pixel text-lg text-green-400 mb-4">Hoedjes</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {Object.values(HATS).filter(hat => hat.price > 0).map(hat => (
                    <button
                      key={hat.id}
                      onClick={() => buyHat(hat)}
                      disabled={character.hat?.id === hat.id}
                      className="p-4 bg-slate-700 pixel-borders hover:border-yellow-400 disabled:opacity-50"
                    >
                      <div className="text-4xl mb-2">{hat.sprite}</div>
                      <p className="font-pixel text-sm">{hat.name}</p>
                      <p className="font-pixel text-xs text-yellow-400">
                        {hat.price} coins
                      </p>
                      {character.hat?.id === hat.id && (
                        <p className="font-pixel text-xs text-green-400 mt-1">Owned</p>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Items */}
              <div>
                <h3 className="font-pixel text-lg text-green-400 mb-4">Items</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.values(SHOP_ITEMS).map(item => (
                    <button
                      key={item.id}
                      onClick={() => buyItem(item)}
                      className="p-4 bg-slate-700 pixel-borders hover:border-yellow-400 text-left"
                    >
                      <h4 className="font-pixel text-sm text-yellow-400">{item.name}</h4>
                      <p className="font-pixel text-xs text-gray-400 mb-2">{item.description}</p>
                      <p className="font-pixel text-xs text-yellow-400">
                        {item.price} coins
                      </p>
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </div>
    </div>
  );
}