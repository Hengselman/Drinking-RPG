# Drinking RPG 🍺🎮

Een epische drankspellen RPG waar je XP verdient, levels omhoog gaat en digitale kleding koopt voor je pixel-art karakter!

## Features

- **5 Save Slots** - Maak tot 5 verschillende karakters
- **4 Classes** - Kies uit Barbaar, Magiër, Schutter of Paladijn
- **Pixel-Art Style** - Retro 8-bit graphics
- **XP & Leveling** - Verdien XP door drankspellen te winnen
- **Shop System** - Koop hoedjes en items met verdiende munten
- **Admin Panel** - Admin kan XP en munten toewijzen aan spelers

## Setup

### 1. Firebase Setup
1. Ga naar [Firebase Console](https://console.firebase.google.com/)
2. Maak een nieuw project aan
3. Schakel Authentication in (Email/Password)
4. Schakel Firestore Database in
5. Kopieer je Firebase configuratie

### 2. Project Setup
```bash
# Installeer dependencies
npm install

# Update src/firebase.js met jouw config
# Vervang de placeholder values met je eigen Firebase config

# Start development server
npm run dev
```

### 3. Admin Account
Pas `src/scripts/initAdmin.js` aan met je Firebase config en run het script om een admin account aan te maken:

```javascript
// Uncomment de laatste regel en run:
node src/scripts/initAdmin.js
```

## Hoe te Spelen

1. **Login/Signup** - Maak een account aan of log in
2. **Kies een Slot** - Selecteer een van de 5 save slots
3. **Maak een Karakter** - Kies naam, class en start hoedje
4. **Speel Drankspellen** - Win XP door spellen te spelen
5. **Shop** - Koop nieuwe hoedjes en items met munten
6. **Level Up** - Word sterker met elk level!

## Admin Features

Als admin kun je:
- Alle karakters bekijken
- XP toewijzen voor gewonnen spellen
- Munten geven aan spelers
- Custom XP/coin amounts instellen

## Drankspellen

- **Mexicaantje** - Dobbelspel met bier (+50 XP)
- **Kingsen** - Kaartspel voor koningen (+75 XP)
- **Flip Cup** - Team bekerflip wedstrijd (+60 XP)  
- **Beer Pong** - Klassieke beker gooien (+80 XP)
- **Ik Heb Nog Nooit** - Onthul je geheimen (+40 XP)

## Tech Stack

- React + Vite
- Firebase (Auth + Firestore)
- Tailwind CSS
- Framer Motion
- React Router

## Deployment

```bash
# Build voor production
npm run build

# Deploy naar Firebase Hosting (optioneel)
firebase deploy
```

Veel plezier met jullie epische drankavond! 🎉
