export const CHARACTER_CLASSES = {
  BARBAAR: {
    id: 'barbaar',
    name: 'Barbaar',
    description: 'Sterk en kan veel drinken',
    baseStats: {
      stamina: 15,
      strength: 12,
      speed: 8
    },
    color: 'bg-red-600'
  },
  MAGIËR: {
    id: 'magier',
    name: 'Magiër',
    description: 'Slimme drinker met trucs',
    baseStats: {
      stamina: 8,
      strength: 6,
      speed: 12
    },
    color: 'bg-purple-600'
  },
  SCHUTTER: {
    id: 'schutter',
    name: 'Schutter',
    description: 'Precies en snel',
    baseStats: {
      stamina: 10,
      strength: 8,
      speed: 15
    },
    color: 'bg-green-600'
  },
  PALADIJN: {
    id: 'paladijn',
    name: 'Paladijn',
    description: 'Eerlijk en standvastig',
    baseStats: {
      stamina: 12,
      strength: 10,
      speed: 10
    },
    color: 'bg-yellow-600'
  }
};

export const HATS = {
  VIKING: {
    id: 'viking',
    name: 'Viking Helm',
    price: 0,
    sprite: '🎩' // Tijdelijk emoji, later pixel art
  },
  WIZARD: {
    id: 'wizard',
    name: 'Tovenaarshoed',
    price: 100,
    sprite: '🧙'
  },
  CROWN: {
    id: 'crown',
    name: 'Gouden Kroon',
    price: 500,
    sprite: '👑'
  },
  PIRATE: {
    id: 'pirate',
    name: 'Piratenhoed',
    price: 200,
    sprite: '🏴‍☠️'
  },
  PARTY: {
    id: 'party',
    name: 'Feesthoed',
    price: 50,
    sprite: '🎉'
  }
};

export const SHOP_ITEMS = {
  // Kleding
  ARMOR_BASIC: {
    id: 'armor_basic',
    name: 'Leren Harnas',
    type: 'armor',
    price: 150,
    description: '+2 Stamina',
    stats: { stamina: 2 }
  },
  ARMOR_CHAIN: {
    id: 'armor_chain',
    name: 'Maliënkolder',
    type: 'armor',
    price: 300,
    description: '+5 Stamina',
    stats: { stamina: 5 }
  },
  BOOTS_SPEED: {
    id: 'boots_speed',
    name: 'Snelheidslaarzen',
    type: 'boots',
    price: 200,
    description: '+3 Speed',
    stats: { speed: 3 }
  },
  GLOVES_POWER: {
    id: 'gloves_power',
    name: 'Krachthandschoenen',
    type: 'gloves',
    price: 180,
    description: '+3 Strength',
    stats: { strength: 3 }
  },
  // Speciale items
  LUCKY_CHARM: {
    id: 'lucky_charm',
    name: 'Geluksbrenger',
    type: 'accessory',
    price: 400,
    description: 'Dubbele XP voor 5 spellen',
    effect: 'double_xp'
  },
  BEER_SHIELD: {
    id: 'beer_shield',
    name: 'Bierschild',
    type: 'accessory',
    price: 350,
    description: 'Bescherming tegen 1 adtje',
    effect: 'protection'
  }
};

export const DRINKING_GAMES = [
  {
    id: 'mexican',
    name: 'Mexicaantje',
    description: 'Dobbelspel met bier',
    xpReward: 50
  },
  {
    id: 'kingsen',
    name: 'Kingsen',
    description: 'Kaartspel voor koningen',
    xpReward: 75
  },
  {
    id: 'flip_cup',
    name: 'Flip Cup',
    description: 'Team bekerflip wedstrijd',
    xpReward: 60
  },
  {
    id: 'beer_pong',
    name: 'Beer Pong',
    description: 'Klassieke beker gooien',
    xpReward: 80
  },
  {
    id: 'never_have_i',
    name: 'Ik Heb Nog Nooit',
    description: 'Onthul je geheimen',
    xpReward: 40
  }
];

export function calculateLevel(xp) {
  // Elke 100 XP is een level
  return Math.floor(xp / 100) + 1;
}

export function getXpForNextLevel(currentXp) {
  const currentLevel = calculateLevel(currentXp);
  return (currentLevel * 100) - currentXp;
}