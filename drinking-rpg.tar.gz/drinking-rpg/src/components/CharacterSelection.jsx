import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { motion } from 'framer-motion';
import { Plus, LogOut, Shield } from 'lucide-react';
import toast from 'react-hot-toast';
import { calculateLevel } from '../data/gameData';

export default function CharacterSelection() {
  const [characters, setCharacters] = useState(Array(5).fill(null));
  const [loading, setLoading] = useState(true);
  const { currentUser, logout, isAdmin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    loadCharacters();
  }, [currentUser]);

  async function loadCharacters() {
    try {
      const userDoc = await getDoc(doc(db, 'users', currentUser.uid));
      if (userDoc.exists()) {
        const userData = userDoc.data();
        setCharacters(userData.characters || Array(5).fill(null));
      }
    } catch (error) {
      toast.error('Fout bij laden karakters');
    } finally {
      setLoading(false);
    }
  }

  async function selectCharacter(index) {
    if (characters[index]) {
      // Sla geselecteerde karakter op
      await updateDoc(doc(db, 'users', currentUser.uid), {
        selectedCharacter: index
      });
      navigate(`/game/${index}`);
    } else {
      // Maak nieuw karakter
      navigate(`/create-character/${index}`);
    }
  }

  async function handleLogout() {
    try {
      await logout();
      navigate('/');
    } catch (error) {
      toast.error('Fout bij uitloggen');
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <p className="font-pixel text-white animate-pulse">Laden...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <h1 className="font-pixel text-3xl text-yellow-400">
            KIES JE KARAKTER
          </h1>
          <div className="flex gap-4">
            {isAdmin && (
              <button
                onClick={() => navigate('/admin')}
                className="pixel-button bg-purple-600 flex items-center gap-2"
              >
                <Shield className="w-4 h-4" />
                Admin
              </button>
            )}
            <button
              onClick={handleLogout}
              className="pixel-button bg-red-600 flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Uitloggen
            </button>
          </div>
        </div>

        {/* Character Slots */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
          {characters.map((character, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <button
                onClick={() => selectCharacter(index)}
                className="w-full h-64 pixel-card hover:border-yellow-400 transition-all group"
              >
                {character ? (
                  <div className="h-full flex flex-col items-center justify-center p-4">
                    {/* Character Display */}
                    <div className="text-6xl mb-4">
                      {character.hat?.sprite || '🎩'}
                    </div>
                    <h3 className="font-pixel text-sm text-yellow-400 mb-2">
                      {character.name}
                    </h3>
                    <p className="font-pixel text-xs text-gray-400 mb-2">
                      {character.class.name}
                    </p>
                    <div className="font-pixel text-xs">
                      <p className="text-green-400">
                        Level {calculateLevel(character.xp || 0)}
                      </p>
                      <p className="text-blue-400">
                        {character.xp || 0} XP
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center">
                    <Plus className="w-16 h-16 text-gray-600 mb-4 group-hover:text-yellow-400 transition-colors" />
                    <p className="font-pixel text-xs text-gray-500 group-hover:text-white">
                      Nieuw Karakter
                    </p>
                    <p className="font-pixel text-xs text-gray-600 mt-2">
                      Slot {index + 1}
                    </p>
                  </div>
                )}
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}