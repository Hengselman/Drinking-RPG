import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './contexts/AuthContext';
import Login from './components/Login';
import CharacterSelection from './components/CharacterSelection';
import CreateCharacter from './components/CreateCharacter';
import Game from './components/Game';
import Admin from './components/Admin';
import PrivateRoute from './components/PrivateRoute';

function App() {
  return (
    <Router>
      <AuthProvider>
        <Toaster 
          position="top-center"
          toastOptions={{
            style: {
              background: '#1e293b',
              color: '#fff',
              border: '2px solid #fff',
              fontFamily: '"Press Start 2P", cursive',
              fontSize: '12px',
              padding: '16px',
            },
          }}
        />
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/characters" element={
            <PrivateRoute>
              <CharacterSelection />
            </PrivateRoute>
          } />
          <Route path="/create-character/:slotIndex" element={
            <PrivateRoute>
              <CreateCharacter />
            </PrivateRoute>
          } />
          <Route path="/game/:slotIndex" element={
            <PrivateRoute>
              <Game />
            </PrivateRoute>
          } />
          <Route path="/admin" element={
            <PrivateRoute>
              <Admin />
            </PrivateRoute>
          } />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;
