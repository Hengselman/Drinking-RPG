import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../firebase';
import { collection, getDocs, doc, updateDoc } from 'firebase/firestore';
import { motion } from 'framer-motion';
import { ArrowLeft, Plus, Coins } from 'lucide-react';
import toast from 'react-hot-toast';
import { calculateLevel, DRINKING_GAMES } from '../data/gameData';

export default function Admin() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState(null);
  const [xpAmount, setXpAmount] = useState(50);
  const [coinAmount, setCoinAmount] = useState(100);
  const { isAdmin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAdmin) {
      navigate('/characters');
      return;
    }
    loadUsers();
  }, [isAdmin]);

  async function loadUsers() {
    try {
      const usersSnapshot = await getDocs(collection(db, 'users'));
      const usersData = [];
      
      usersSnapshot.forEach((doc) => {
        const userData = doc.data();
        if (userData.characters && userData.characters.length > 0) {
          userData.characters.forEach((char, index) => {
            if (char) {
              usersData.push({
                userId: doc.id,
                email: userData.email,
                characterIndex: index,
                character: char
              });
            }
          });
        }
      });
      
      setUsers(usersData);
    } catch (error) {
      toast.error('Fout bij laden gebruikers');
    } finally {
      setLoading(false);
    }
  }

  async function addXP(user, game = null) {
    try {
      const userRef = doc(db, 'users', user.userId);
      const userSnapshot = await getDocs(collection(db, 'users'));
      let userData;
      
      userSnapshot.forEach((docSnap) => {
        if (docSnap.id === user.userId) {
          userData = docSnap.data();
        }
      });

      if (!userData) return;

      const characters = [...userData.characters];
      const xpToAdd = game ? game.xpReward : xpAmount;
      characters[user.characterIndex] = {
        ...characters[user.characterIndex],
        xp: (characters[user.characterIndex].xp || 0) + xpToAdd
      };

      await updateDoc(userRef, { characters });
      
      toast.success(`${xpToAdd} XP toegevoegd aan ${user.character.name}!`);
      loadUsers(); // Refresh
    } catch (error) {
      toast.error('Fout bij toevoegen XP');
    }
  }

  async function addCoins(user) {
    try {
      const userRef = doc(db, 'users', user.userId);
      const userSnapshot = await getDocs(collection(db, 'users'));
      let userData;
      
      userSnapshot.forEach((docSnap) => {
        if (docSnap.id === user.userId) {
          userData = docSnap.data();
        }
      });

      if (!userData) return;

      const characters = [...userData.characters];
      characters[user.characterIndex] = {
        ...characters[user.characterIndex],
        currency: (characters[user.characterIndex].currency || 0) + coinAmount
      };

      await updateDoc(userRef, { characters });
      
      toast.success(`${coinAmount} munten toegevoegd aan ${user.character.name}!`);
      loadUsers(); // Refresh
    } catch (error) {
      toast.error('Fout bij toevoegen munten');
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900">
        <p className="font-pixel text-white animate-pulse">Laden...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={() => navigate('/characters')}
            className="pixel-button bg-gray-600 mr-4"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h1 className="font-pixel text-3xl text-yellow-400">
            ADMIN PANEL
          </h1>
        </div>

        {/* Controls */}
        <div className="pixel-card mb-6">
          <h2 className="font-pixel text-xl text-yellow-400 mb-4">Instellingen</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block font-pixel text-xs mb-2">Custom XP Amount</label>
              <input
                type="number"
                value={xpAmount}
                onChange={(e) => setXpAmount(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-700 border-2 border-slate-600 text-white font-pixel text-xs"
              />
            </div>
            <div>
              <label className="block font-pixel text-xs mb-2">Coin Amount</label>
              <input
                type="number"
                value={coinAmount}
                onChange={(e) => setCoinAmount(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-2 bg-slate-700 border-2 border-slate-600 text-white font-pixel text-xs"
              />
            </div>
          </div>
        </div>

        {/* Users List */}
        <div className="pixel-card">
          <h2 className="font-pixel text-xl text-yellow-400 mb-4">Alle Karakters</h2>
          <div className="space-y-4">
            {users.map((user, index) => (
              <motion.div
                key={`${user.userId}-${user.characterIndex}`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="p-4 bg-slate-800 pixel-borders"
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <div className="text-4xl">{user.character.hat?.sprite || '🎩'}</div>
                    <div>
                      <h3 className="font-pixel text-sm text-yellow-400">
                        {user.character.name}
                      </h3>
                      <p className="font-pixel text-xs text-gray-400">
                        {user.email} - {user.character.class.name}
                      </p>
                      <div className="font-pixel text-xs mt-1">
                        <span className="text-green-400">
                          Level {calculateLevel(user.character.xp || 0)} - {user.character.xp || 0} XP
                        </span>
                        <span className="text-yellow-400 ml-4">
                          {user.character.currency || 0} coins
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {/* Quick Game XP Buttons */}
                    {DRINKING_GAMES.slice(0, 3).map(game => (
                      <button
                        key={game.id}
                        onClick={() => addXP(user, game)}
                        className="pixel-button bg-blue-600 text-xs"
                        title={game.name}
                      >
                        +{game.xpReward} XP
                      </button>
                    ))}
                    
                    {/* Custom XP */}
                    <button
                      onClick={() => addXP(user)}
                      className="pixel-button bg-green-600 text-xs flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" />
                      {xpAmount} XP
                    </button>
                    
                    {/* Add Coins */}
                    <button
                      onClick={() => addCoins(user)}
                      className="pixel-button bg-yellow-600 text-xs flex items-center gap-1"
                    >
                      <Coins className="w-3 h-3" />
                      {coinAmount}
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          {users.length === 0 && (
            <p className="font-pixel text-xs text-gray-500 text-center py-8">
              Nog geen karakters aangemaakt...
            </p>
          )}
        </div>
      </div>
    </div>
  );
}